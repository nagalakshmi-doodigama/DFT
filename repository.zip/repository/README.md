# Accurate-approximate-multipliers
This library provides the FPGA optimized accurate and approximate multipliers.
